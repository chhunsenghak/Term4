function addNumber(a, b) {
  return a + b;
}

// The function call below should print: 10 but now it's 64
console.log(addNumber("6", "4"));


