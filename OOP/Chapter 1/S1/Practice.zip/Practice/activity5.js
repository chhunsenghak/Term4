// TODO :
// - Check the result is not correct !
// - Add some anotation to type the function parameters
// - Fx the errors then in the code
function sayManyTimes(name, count) {
    for (var i = 0; i < count; i += 1) {
        console.log(name);
    }
}
// Say  'Muriel!' six times
sayManyTimes("Muriel", 6);
