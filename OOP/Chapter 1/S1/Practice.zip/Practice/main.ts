let teachername;
teachername=10;
teachername="SENGHAK";
console.log(teachername);
let him: string = "rean smart";