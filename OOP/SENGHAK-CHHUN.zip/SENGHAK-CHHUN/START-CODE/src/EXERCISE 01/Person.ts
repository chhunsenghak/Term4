export abstract class Person {
    constructor(protected name: string, protected age: number) {}
}