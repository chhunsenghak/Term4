export class dish {
    constructor(private name: string, private description: string, private price: string) { }
}