<template>
  <div class="container d-flex align-items-center justify-content-center">
    <CardComponent :book="book" @Show="Show"></CardComponent>
    <div class="container">
      <table-vue :data="data" ​​></table-vue>
    </div>
  </div>
</template>

<script>
import CardComponent from "./components/CardComponent.vue";
import tableVue from "./components/TableComponent.vue";
export default {
  name: "App",
  components: {
    CardComponent,
    tableVue,
  },

  data() {
    return {
      data: "",
      showNow: false,
      book: {
        title: "The Lord of the Rings",
        author: "Tolkien",
        year: 1954,
        image:
          "https://static.toiimg.com/photo/msid-103053443,width-96,height-65.cms",
      },
    };
  },
  methods: {
    Show(data) {
      this.data = data;
    },
  },
};
</script>

<style>
</style>
