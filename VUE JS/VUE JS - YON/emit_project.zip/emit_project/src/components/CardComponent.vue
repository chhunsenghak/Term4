<template>
  <div class="card" style="width: 18rem">
    <img class="card-img-top" :src="book.image" alt="Card image cap" />
    <div class="card-body">
      <h5 class="card-title">{{ book.title }}</h5>
      <p class="card-text">{{ book.author }}</p>
      <p class="card-text">{{ book.year }}</p>
      <a href="#" @click="see_more" class="btn btn-primary">Go somewhere</a>
    </div>
  </div>
</template>

<script>
export default {
  name: "CardComponent",
  props: ["book"],
  // book : '',
  methods: {
    see_more() {
      this.$emit("Show", this.book);
    },
  },
};
</script>

<style>
</style>