<template>
  <div class="alert">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: "AlertMessage",
};
</script>

<style>
</style>